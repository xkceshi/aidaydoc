import aiohttp
from typing import List, Dict
import logging
from datetime import datetime
import re

logger = logging.getLogger('daydoc')

class ContentProcessor:
    def __init__(self, config: Dict):
        self.config = config
        self.api_endpoint = config['api_endpoint']
        self.api_key = config['api_key']
        self.model = config['model']
        self.temperature = config['temperature']
        self.max_tokens = config['max_tokens']

    async def process(self, articles: List[Dict]) -> Dict:
        logger.info("开始使用 AI 处理文章内容")
        try:
            prompt = self._prepare_prompt(articles)
            
            async with aiohttp.ClientSession() as session:
                headers = {
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json"
                }
                
                current_date = datetime.now().strftime("%Y%m%d")
                
                payload = {
                    "model": self.model,
                    "messages": [
                        {"role": "system", "content": "你是一个专业的科技新闻编辑，善于总结和归纳新闻要点，擅长写出吸引人的标题。"},
                        {"role": "user", "content": prompt}
                    ],
                    "temperature": self.temperature,
                    "max_tokens": self.max_tokens
                }
                
                logger.info("正在调用 AI 接口...")
                async with session.post(self.api_endpoint, headers=headers, json=payload) as response:
                    result = await response.json()
                    content = result['choices'][0]['message']['content']
                    
                    # 添加文章元信息（使用Markdown格式）
                    sources = list(set(article['source'] for article in articles))
                    footer = f"\n\n---\n\n**作者**：{self.model}  \n**文章来源**：{', '.join(sources)}  \n**编辑**：小康"
                    content_with_footer = content + footer
                    
                    return {
                        "title": f"【{current_date}AI日报】{self._extract_highlight_title(articles)}",
                        "content": content_with_footer,
                        "source_articles": articles
                    }
        except Exception as e:
            logger.error(f"AI 处理失败: {str(e)}")
            raise

    def _prepare_prompt(self, articles: List[Dict]) -> str:
        articles_info = []
        for article in articles:
            # 尝试从摘要中提取图片链接
            summary = article.get('summary', '')
            img_match = re.search(r'<img.*?src="(.*?)"', summary)
            img_url = img_match.group(1) if img_match else ''
            
            article_info = f"""标题：{article['title']}
来源：{article['source']}
链接：{article['link']}
图片：{img_url}
摘要：{re.sub(r'<.*?>', '', summary)}
"""
            articles_info.append(article_info)
        
        articles_text = "\n\n".join(articles_info)
        
        return f"""请基于以下新闻生成一篇AI科技日报，使用Markdown格式，要求：

1. 文章结构：
   - 开头：# 标题
   - 第一段：最重要的新闻，使用引用格式（>），包含新闻标题、图片和概要
   - 中间部分：其他新闻，每条使用二级标题（##），包含图片（如有）和内容
   - 最后：使用二级标题（## 总结），总结今日AI领域发展趋势

2. 格式要求：
   - 图片使用标准Markdown格式：![图片描述](图片URL)
   - 新闻标题需要加粗：**标题**
   - 重要内容使用引用格式（>）
   - 适当使用分隔线（---）分隔不同部分
   - 每条新闻末尾添加原文链接：[原文链接](URL)

3. 内容要求：
   - 保持专业客观的语气
   - 突出重要信息和关键进展
   - 保持逻辑清晰，段落分明
   - 确保引用原文图片URL

新闻信息如下：
{articles_text}"""

    def _extract_highlight_title(self, articles: List[Dict]) -> str:
        # 这里可以实现一个简单的算法来选择最吸引人的标题
        # 目前简单返回第一篇文章的标题
        if articles:
            return articles[0]['title']
        return "今日AI要闻汇总"