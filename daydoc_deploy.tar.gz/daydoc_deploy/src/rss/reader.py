import feedparser
import asyncio
import aiohttp
from datetime import datetime, timedelta
from typing import List, Dict
import logging
import time
from email.utils import parsedate_to_datetime

logger = logging.getLogger('daydoc')

class RSSReader:
    def __init__(self, sources: List[Dict]):
        self.sources = sources

    async def fetch_feed(self, session: aiohttp.ClientSession, source: Dict) -> List[Dict]:
        try:
            logger.info(f"开始获取 {source['name']} 的 RSS 内容")
            async with session.get(source['url']) as response:
                content = await response.text()
                feed = feedparser.parse(content)
                
                articles = []
                current_time = datetime.now()
                cutoff_time = current_time - timedelta(hours=24)
                
                for entry in feed.entries:
                    try:
                        # 解析发布时间
                        if 'published_parsed' in entry:
                            pub_date = datetime.fromtimestamp(time.mktime(entry.published_parsed))
                        elif 'published' in entry:
                            pub_date = parsedate_to_datetime(entry.published)
                        else:
                            continue
                        
                        # 检查是否在24小时内
                        if pub_date < cutoff_time:
                            continue
                        
                        article = {
                            'title': entry.title,
                            'link': entry.link,
                            'source': source['name'],
                            'published': pub_date.isoformat(),
                            'summary': entry.get('summary', ''),
                            'importance_score': self._calculate_importance(entry)
                        }
                        articles.append(article)
                        
                        if len(articles) >= 10:  # 每个源最多10篇
                            break
                            
                    except Exception as e:
                        logger.warning(f"处理文章时出错: {str(e)}")
                        continue
                
                logger.info(f"从 {source['name']} 获取到 {len(articles)} 篇24小时内的文章")
                return articles
        except Exception as e:
            logger.error(f"从 {source['name']} 获取内容失败: {str(e)}")
            return []

    def _calculate_importance(self, entry) -> float:
        """计算文章重要性分数"""
        score = 0.0
        
        # 根据标题关键词加分
        important_keywords = ['突破', 'breakthrough', '发布', 'release', '重要', 'important',
                            '最新', 'latest', '重磅', '革命性', 'revolutionary']
        title_lower = entry.title.lower()
        for keyword in important_keywords:
            if keyword.lower() in title_lower:
                score += 1.0
        
        # 根据内容长度加分
        if 'summary' in entry:
            score += min(len(entry.summary) / 1000, 2.0)  # 最多加2分
        
        # 根据发布时间加分（越新越重要）
        if 'published_parsed' in entry:
            hours_ago = (datetime.now() - datetime.fromtimestamp(time.mktime(entry.published_parsed))).total_seconds() / 3600
            score += max(0, 2.0 * (24 - hours_ago) / 24)  # 最多加2分
        
        return score

    async def fetch_all(self) -> List[Dict]:
        async with aiohttp.ClientSession() as session:
            tasks = [self.fetch_feed(session, source) for source in self.sources]
            results = await asyncio.gather(*tasks)
            
            # 合并所有文章
            all_articles = []
            for articles in results:
                all_articles.extend(articles)
            
            # 去重（基于标题）
            seen_titles = set()
            unique_articles = []
            for article in all_articles:
                if article['title'] not in seen_titles:
                    seen_titles.add(article['title'])
                    unique_articles.append(article)
            
            # 按重要性排序并选择前10-15篇
            sorted_articles = sorted(unique_articles, 
                                  key=lambda x: x['importance_score'], 
                                  reverse=True)
            final_articles = sorted_articles[:15]  # 最多保留15篇
            
            logger.info(f"总共获取 {len(all_articles)} 篇文章，"
                       f"去重后 {len(unique_articles)} 篇，"
                       f"最终选择 {len(final_articles)} 篇重要文章")
            
            return final_articles