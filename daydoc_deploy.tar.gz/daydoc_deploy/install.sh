#!/bin/bash
set -e

# 创建虚拟环境
python3 -m venv venv
source venv/bin/activate

# 安装依赖
pip install -r requirements.txt

# 设置执行权限
chmod +x run.py

# 设置 cron 任务
(crontab -l 2>/dev/null || true; echo "0 6 * * * cd $(pwd) && source venv/bin/activate && ./run.py >> $(pwd)/logs/cron.log 2>&1") | crontab -

echo "安装完成！"
