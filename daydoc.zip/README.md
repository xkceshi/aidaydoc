├── src/
│   ├── rss/          # RSS 订阅和解析
│   ├── ai/           # AI 处理模块
│   ├── blog/         # 博客发布接口
│   └── utils/        # 工具函数
├── config/           # 配置文件
├── main.py          # 主程序
└── requirements.txt  # 依赖管理