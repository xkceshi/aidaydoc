# 部署指南

1. 在服务器上安装依赖：
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt